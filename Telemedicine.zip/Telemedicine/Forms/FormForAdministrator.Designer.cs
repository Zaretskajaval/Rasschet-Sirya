﻿namespace Telemedicine.Forms
{
    partial class FormForAdministrator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormForAdministrator));
            this.groupBoxReports = new System.Windows.Forms.GroupBox();
            this.buttonAllDoctors = new System.Windows.Forms.Button();
            this.buttonPatientsMen = new System.Windows.Forms.Button();
            this.buttonPatienWomen = new System.Windows.Forms.Button();
            this.buttonNewSeanses = new System.Windows.Forms.Button();
            this.buttonSeansInPast = new System.Windows.Forms.Button();
            this.groupBoxCreateDoctor = new System.Windows.Forms.GroupBox();
            this.buttonCreateNewDoctor = new System.Windows.Forms.Button();
            this.textBoxNewPassDoctor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxLoginNewDoctor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxStage = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxSpeciality = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxFIODoctor = new System.Windows.Forms.TextBox();
            this.groupBoxDeleteDoctor = new System.Windows.Forms.GroupBox();
            this.buttonDeleteDataDoctor = new System.Windows.Forms.Button();
            this.textBoxFIODeleteDoctor = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBoxReports.SuspendLayout();
            this.groupBoxCreateDoctor.SuspendLayout();
            this.groupBoxDeleteDoctor.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxReports
            // 
            this.groupBoxReports.Controls.Add(this.buttonAllDoctors);
            this.groupBoxReports.Controls.Add(this.buttonPatientsMen);
            this.groupBoxReports.Controls.Add(this.buttonPatienWomen);
            this.groupBoxReports.Controls.Add(this.buttonNewSeanses);
            this.groupBoxReports.Controls.Add(this.buttonSeansInPast);
            this.groupBoxReports.Location = new System.Drawing.Point(773, 38);
            this.groupBoxReports.Name = "groupBoxReports";
            this.groupBoxReports.Size = new System.Drawing.Size(298, 385);
            this.groupBoxReports.TabIndex = 2;
            this.groupBoxReports.TabStop = false;
            this.groupBoxReports.Text = "ОТЧЕТЫ";
            // 
            // buttonAllDoctors
            // 
            this.buttonAllDoctors.Location = new System.Drawing.Point(27, 305);
            this.buttonAllDoctors.Name = "buttonAllDoctors";
            this.buttonAllDoctors.Size = new System.Drawing.Size(239, 44);
            this.buttonAllDoctors.TabIndex = 4;
            this.buttonAllDoctors.Text = "Список всех докторов";
            this.buttonAllDoctors.UseVisualStyleBackColor = true;
            this.buttonAllDoctors.Click += new System.EventHandler(this.buttonAllDoctors_Click);
            // 
            // buttonPatientsMen
            // 
            this.buttonPatientsMen.Location = new System.Drawing.Point(27, 240);
            this.buttonPatientsMen.Name = "buttonPatientsMen";
            this.buttonPatientsMen.Size = new System.Drawing.Size(239, 44);
            this.buttonPatientsMen.TabIndex = 3;
            this.buttonPatientsMen.Text = "Все пациенты мужчины";
            this.buttonPatientsMen.UseVisualStyleBackColor = true;
            this.buttonPatientsMen.Click += new System.EventHandler(this.buttonPatientsMen_Click);
            // 
            // buttonPatienWomen
            // 
            this.buttonPatienWomen.Location = new System.Drawing.Point(27, 177);
            this.buttonPatienWomen.Name = "buttonPatienWomen";
            this.buttonPatienWomen.Size = new System.Drawing.Size(239, 44);
            this.buttonPatienWomen.TabIndex = 2;
            this.buttonPatienWomen.Text = "Все пациенты женщины";
            this.buttonPatienWomen.UseVisualStyleBackColor = true;
            this.buttonPatienWomen.Click += new System.EventHandler(this.buttonPatienWomen_Click);
            // 
            // buttonNewSeanses
            // 
            this.buttonNewSeanses.Location = new System.Drawing.Point(27, 117);
            this.buttonNewSeanses.Name = "buttonNewSeanses";
            this.buttonNewSeanses.Size = new System.Drawing.Size(239, 44);
            this.buttonNewSeanses.TabIndex = 1;
            this.buttonNewSeanses.Text = "Сеансы в ожидании";
            this.buttonNewSeanses.UseVisualStyleBackColor = true;
            this.buttonNewSeanses.Click += new System.EventHandler(this.buttonNewSeanses_Click);
            // 
            // buttonSeansInPast
            // 
            this.buttonSeansInPast.Location = new System.Drawing.Point(27, 58);
            this.buttonSeansInPast.Name = "buttonSeansInPast";
            this.buttonSeansInPast.Size = new System.Drawing.Size(239, 44);
            this.buttonSeansInPast.TabIndex = 0;
            this.buttonSeansInPast.Text = "Завершенные сеансы";
            this.buttonSeansInPast.UseVisualStyleBackColor = true;
            this.buttonSeansInPast.Click += new System.EventHandler(this.buttonSeansInPast_Click);
            // 
            // groupBoxCreateDoctor
            // 
            this.groupBoxCreateDoctor.Controls.Add(this.buttonCreateNewDoctor);
            this.groupBoxCreateDoctor.Controls.Add(this.textBoxNewPassDoctor);
            this.groupBoxCreateDoctor.Controls.Add(this.label6);
            this.groupBoxCreateDoctor.Controls.Add(this.textBoxLoginNewDoctor);
            this.groupBoxCreateDoctor.Controls.Add(this.label5);
            this.groupBoxCreateDoctor.Controls.Add(this.textBoxStage);
            this.groupBoxCreateDoctor.Controls.Add(this.label4);
            this.groupBoxCreateDoctor.Controls.Add(this.textBoxTime);
            this.groupBoxCreateDoctor.Controls.Add(this.label3);
            this.groupBoxCreateDoctor.Controls.Add(this.textBoxSpeciality);
            this.groupBoxCreateDoctor.Controls.Add(this.label2);
            this.groupBoxCreateDoctor.Controls.Add(this.label1);
            this.groupBoxCreateDoctor.Controls.Add(this.textBoxFIODoctor);
            this.groupBoxCreateDoctor.Location = new System.Drawing.Point(12, 101);
            this.groupBoxCreateDoctor.Name = "groupBoxCreateDoctor";
            this.groupBoxCreateDoctor.Size = new System.Drawing.Size(431, 329);
            this.groupBoxCreateDoctor.TabIndex = 3;
            this.groupBoxCreateDoctor.TabStop = false;
            this.groupBoxCreateDoctor.Text = "Записи в базе данных";
            // 
            // buttonCreateNewDoctor
            // 
            this.buttonCreateNewDoctor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonCreateNewDoctor.Location = new System.Drawing.Point(120, 255);
            this.buttonCreateNewDoctor.Name = "buttonCreateNewDoctor";
            this.buttonCreateNewDoctor.Size = new System.Drawing.Size(223, 55);
            this.buttonCreateNewDoctor.TabIndex = 13;
            this.buttonCreateNewDoctor.Text = "Создать нового врача";
            this.buttonCreateNewDoctor.UseVisualStyleBackColor = false;
            this.buttonCreateNewDoctor.Click += new System.EventHandler(this.buttonCreateNewDoctor_Click);
            // 
            // textBoxNewPassDoctor
            // 
            this.textBoxNewPassDoctor.Location = new System.Drawing.Point(239, 208);
            this.textBoxNewPassDoctor.Name = "textBoxNewPassDoctor";
            this.textBoxNewPassDoctor.Size = new System.Drawing.Size(186, 26);
            this.textBoxNewPassDoctor.TabIndex = 11;
            this.textBoxNewPassDoctor.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(304, 177);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Пароль";
            // 
            // textBoxLoginNewDoctor
            // 
            this.textBoxLoginNewDoctor.Location = new System.Drawing.Point(239, 141);
            this.textBoxLoginNewDoctor.Name = "textBoxLoginNewDoctor";
            this.textBoxLoginNewDoctor.Size = new System.Drawing.Size(186, 26);
            this.textBoxLoginNewDoctor.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(304, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Логин";
            // 
            // textBoxStage
            // 
            this.textBoxStage.Location = new System.Drawing.Point(239, 76);
            this.textBoxStage.Name = "textBoxStage";
            this.textBoxStage.Size = new System.Drawing.Size(186, 26);
            this.textBoxStage.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(276, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Стаж (в годах)";
            // 
            // textBoxTime
            // 
            this.textBoxTime.Location = new System.Drawing.Point(6, 208);
            this.textBoxTime.Name = "textBoxTime";
            this.textBoxTime.Size = new System.Drawing.Size(216, 26);
            this.textBoxTime.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Время работы";
            // 
            // textBoxSpeciality
            // 
            this.textBoxSpeciality.Location = new System.Drawing.Point(6, 141);
            this.textBoxSpeciality.Name = "textBoxSpeciality";
            this.textBoxSpeciality.Size = new System.Drawing.Size(216, 26);
            this.textBoxSpeciality.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Специальность";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "ФИО врача";
            // 
            // textBoxFIODoctor
            // 
            this.textBoxFIODoctor.Location = new System.Drawing.Point(6, 76);
            this.textBoxFIODoctor.Name = "textBoxFIODoctor";
            this.textBoxFIODoctor.Size = new System.Drawing.Size(216, 26);
            this.textBoxFIODoctor.TabIndex = 0;
            // 
            // groupBoxDeleteDoctor
            // 
            this.groupBoxDeleteDoctor.Controls.Add(this.buttonDeleteDataDoctor);
            this.groupBoxDeleteDoctor.Controls.Add(this.textBoxFIODeleteDoctor);
            this.groupBoxDeleteDoctor.Controls.Add(this.label7);
            this.groupBoxDeleteDoctor.Location = new System.Drawing.Point(474, 106);
            this.groupBoxDeleteDoctor.Name = "groupBoxDeleteDoctor";
            this.groupBoxDeleteDoctor.Size = new System.Drawing.Size(281, 205);
            this.groupBoxDeleteDoctor.TabIndex = 12;
            this.groupBoxDeleteDoctor.TabStop = false;
            this.groupBoxDeleteDoctor.Text = "Удаление записи о враче";
            // 
            // buttonDeleteDataDoctor
            // 
            this.buttonDeleteDataDoctor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.buttonDeleteDataDoctor.Location = new System.Drawing.Point(20, 114);
            this.buttonDeleteDataDoctor.Name = "buttonDeleteDataDoctor";
            this.buttonDeleteDataDoctor.Size = new System.Drawing.Size(255, 62);
            this.buttonDeleteDataDoctor.TabIndex = 2;
            this.buttonDeleteDataDoctor.Text = "Удалить данные о враче";
            this.buttonDeleteDataDoctor.UseVisualStyleBackColor = false;
            this.buttonDeleteDataDoctor.Click += new System.EventHandler(this.buttonDeleteDataDoctor_Click);
            // 
            // textBoxFIODeleteDoctor
            // 
            this.textBoxFIODeleteDoctor.Location = new System.Drawing.Point(20, 66);
            this.textBoxFIODeleteDoctor.Name = "textBoxFIODeleteDoctor";
            this.textBoxFIODeleteDoctor.Size = new System.Drawing.Size(251, 26);
            this.textBoxFIODeleteDoctor.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(109, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "ФИО врача";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(506, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(226, 37);
            this.label8.TabIndex = 13;
            this.label8.Text = "Удалить врача";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(125, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(230, 37);
            this.label9.TabIndex = 14;
            this.label9.Text = "Создать врача";
            // 
            // FormForAdministrator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 477);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.groupBoxCreateDoctor);
            this.Controls.Add(this.groupBoxDeleteDoctor);
            this.Controls.Add(this.groupBoxReports);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1105, 533);
            this.MinimumSize = new System.Drawing.Size(1105, 533);
            this.Name = "FormForAdministrator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Форма администратора";
            this.Load += new System.EventHandler(this.FormForAdministrator_Load);
            this.groupBoxReports.ResumeLayout(false);
            this.groupBoxCreateDoctor.ResumeLayout(false);
            this.groupBoxCreateDoctor.PerformLayout();
            this.groupBoxDeleteDoctor.ResumeLayout(false);
            this.groupBoxDeleteDoctor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBoxReports;
        private System.Windows.Forms.Button buttonAllDoctors;
        private System.Windows.Forms.Button buttonPatientsMen;
        private System.Windows.Forms.Button buttonPatienWomen;
        private System.Windows.Forms.Button buttonNewSeanses;
        private System.Windows.Forms.Button buttonSeansInPast;
        private System.Windows.Forms.GroupBox groupBoxCreateDoctor;
        private System.Windows.Forms.TextBox textBoxFIODoctor;
        private System.Windows.Forms.TextBox textBoxLoginNewDoctor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxStage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxTime;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxSpeciality;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxNewPassDoctor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBoxDeleteDoctor;
        private System.Windows.Forms.TextBox textBoxFIODeleteDoctor;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonCreateNewDoctor;
        private System.Windows.Forms.Button buttonDeleteDataDoctor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}