﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Telemedicine.Model;

namespace Telemedicine.Forms
{
    public partial class FormForAdministrator : Form
    {
        public FormForAdministrator()
        {
            InitializeComponent();
        }

        private void buttonPatienWomen_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand(@"
                SELECT PatientFullName, DateOfBirdth, Pol, Telefon, Email
                FROM Patient
                WHERE Pol = 'Женский'", connection);

                    // Создаем объект для записи в файл
                    using (StreamWriter writer = new StreamWriter("Все пациенты - женщины.txt"))
                    {
                        // Выполняем запрос и считываем результаты
                        using (SqlDataReader reader = sqlQuery.ExecuteReader())
                        {
                            // Проверяем, есть ли данные для чтения
                            if (reader.HasRows)
                            {
                                // Читаем данные построчно
                                while (reader.Read())
                                {
                                    // Формируем строку с данными
                                    string row = $"ФИО пациента: {reader["PatientFullName"]}\n " +
                                                 $"Дата рождения: {reader["DateOfBirdth"]}\n " +
                                                 $"Пол: {reader["Pol"]}\n " +
                                                 $"Телефон: {reader["Telefon"]}\n " +
                                                 $"Email: {reader["Email"]}\n\n";

                                    // Записываем строку в файл
                                    writer.WriteLine(row);
                                }
                            }
                        }
                    }
                }

                MessageBox.Show("Информация о женских пациентах успешно сохранена в файл Все пациенты - женщины.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }

        }

        private void buttonPatientsMen_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand(@"
                SELECT PatientFullName, DateOfBirdth, Pol, Telefon, Email
                FROM Patient
                WHERE Pol = 'мужской'", connection);

                    // Создаем объект для записи в файл
                    using (StreamWriter writer = new StreamWriter("Все пациенты мужского пола.txt"))
                    {
                        // Выполняем запрос и считываем результаты
                        using (SqlDataReader reader = sqlQuery.ExecuteReader())
                        {
                            // Проверяем, есть ли данные для чтения
                            if (reader.HasRows)
                            {
                                // Читаем данные построчно
                                while (reader.Read())
                                {
                                    // Формируем строку с данными
                                    string row = $"ФИО пациента: {reader["PatientFullName"]}\n " +
                                                 $"Дата рождения: {reader["DateOfBirdth"]}\n " +
                                                 $"Пол: {reader["Pol"]}\n " +
                                                 $"Телефон: {reader["Telefon"]}\n " +
                                                 $"Email: {reader["Email"]}\n\n";

                                    // Записываем строку в файл
                                    writer.WriteLine(row);
                                }
                            }
                        }
                    }
                }

                MessageBox.Show("Информация о мужских пациентах успешно сохранена в файл Все пациенты мужского пола.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

   

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormForAdministrator_Load(object sender, EventArgs e)
        {
            
        }


        private void buttonSeansInPast_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand(@"SELECT Doctor.DoctorFullName AS DoctorName,Patient.PatientFullName AS PatientName,HistoryConsultation.DescriptionOfProblem,HistoryConsultation.DateConsultation,HistoryConsultation.Protokol FROM HistoryConsultation JOIN Doctor ON HistoryConsultation.DoctorID = Doctor.DoctorID JOIN 
                     Patient ON HistoryConsultation.PatientID = Patient.PatientID", connection);
                
                    sqlQuery.ExecuteNonQuery();
                    using (StreamWriter writer = new StreamWriter("Завершенные сеансы.txt"))
                    {
                        // Выполняем запрос и считываем результаты
                        using (SqlDataReader reader = sqlQuery.ExecuteReader())
                        {
                            // Проверяем, есть ли данные для чтения
                            if (reader.HasRows)
                            {
                                // Читаем данные построчно
                                while (reader.Read())
                                {
                                    // Формируем строку с данными
                                    string row = $"Врач: {reader["DoctorName"]}\n " +
                                                 $"Пациент: {reader["PatientName"]}\n " +
                                                 $"Описание проблемы: {reader["DescriptionOfProblem"]}\n " +
                                                 $"Дата консультации: {reader["DateConsultation"]}\n " +
                                                 $"Протокол: {reader["Protokol"]}\n\n";

                                    // Записываем строку в файл
                                    writer.WriteLine(row);
                                }
                            }
                        }
                    }
                    MessageBox.Show("Данные успешно сохранены в файл Завершенные сеансы.txt");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании отчета : " + ex.Message);
            }
        }

        private void buttonCreateNewDoctor_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand("INSERT INTO [Doctor] (DoctorFullName,Speciality,TimeOfWork,Experience,Login,Password) VALUES (@DoctorFullName, @Speciality, @TimeOfWork, @Experience, @Login, @Password)", connection);

                    sqlQuery.Parameters.AddWithValue("@DoctorFullName", textBoxFIODoctor.Text);
                    sqlQuery.Parameters.AddWithValue("@Speciality", textBoxSpeciality.Text);
                    sqlQuery.Parameters.AddWithValue("@TimeOfWork", textBoxTime.Text);
                    sqlQuery.Parameters.AddWithValue("@Experience", textBoxStage.Text);
                    sqlQuery.Parameters.AddWithValue("@Login", textBoxLoginNewDoctor.Text);
                    sqlQuery.Parameters.AddWithValue("@Password", textBoxNewPassDoctor.Text);


                    sqlQuery.ExecuteNonQuery();

                    MessageBox.Show($"Врач успешно создан!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании врача: " + ex.Message);
            }
        }

        private void buttonDeleteDataDoctor_Click(object sender, EventArgs e)
        {
            int doctorID = 0;
            try
            {
                // Создаем объект подключения к базе данных
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand("SELECT DoctorID FROM Doctor WHERE DoctorFullName = @DoctorFullName", connection);
                    sqlQuery.Parameters.AddWithValue("@DoctorFullName", textBoxFIODeleteDoctor.Text);

                    // Выполняем запрос и получаем ID врача
                    try
                    {
                         doctorID = (int)sqlQuery.ExecuteScalar();

                    }
                    catch (System.NullReferenceException)
                    {
                        MessageBox.Show("Ошибка при удалении врача. Такой врач не найден");

                    }


                    // Если врач найден, создаем запрос на удаление его записи
                    if (doctorID != 0)
                    {
                        SqlCommand deleteQuery = new SqlCommand("DELETE FROM Doctor WHERE DoctorID = @DoctorID", connection);
                        deleteQuery.Parameters.AddWithValue("@DoctorID", doctorID);
                        deleteQuery.ExecuteNonQuery();

                        MessageBox.Show("Врач успешно удален!");
                    }
                  
                }
            }
            catch (System.NullReferenceException)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка при удалении врача. Такой врач не найден" );
            }
        }

        private void buttonNewSeanses_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand(@"
                SELECT Doctor.DoctorFullName AS DoctorName,
                       Patient.PatientFullName AS PatientName,
                       ConsultationRequests.DescriptionOfProblem,
                       ConsultationRequests.DateCreateRequest,
                       ConsultationRequests.DateConsultation,
                       ConsultationRequests.TimeOfConsultation
                FROM ConsultationRequests
                JOIN Doctor ON ConsultationRequests.DoctorID = Doctor.DoctorID
                JOIN Patient ON ConsultationRequests.PatientID = Patient.PatientID
                WHERE ConsultationRequests.Status = 1", connection);

                    // Создаем объект для записи в файл
                    using (StreamWriter writer = new StreamWriter("Сеансы в ожидании.txt"))
                    {
                        // Выполняем запрос и считываем результаты
                        using (SqlDataReader reader = sqlQuery.ExecuteReader())
                        {
                            // Проверяем, есть ли данные для чтения
                            if (reader.HasRows)
                            {
                                // Читаем данные построчно
                                while (reader.Read())
                                {
                                    // Формируем строку с данными
                                    string row = $"Врач: {reader["DoctorName"]}\n " +
                                                 $"Пациент: {reader["PatientName"]}\n " +
                                                 $"Описание проблемы: {reader["DescriptionOfProblem"]}\n " +
                                                 $"Дата создания запроса: {reader["DateCreateRequest"]}\n " +
                                                 $"Дата консультации: {reader["DateConsultation"]}\n " +
                                                 $"Время консультации: {reader["TimeOfConsultation"]}\n\n";

                                    // Записываем строку в файл
                                    writer.WriteLine(row);
                                }
                            }
                        }
                    }
                }

                MessageBox.Show("Данные о сеансах в ожидании успешно сохранены в файл Сеансы в ожидании.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }

        private void buttonAllDoctors_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand(@"
                SELECT DoctorFullName, Speciality, TimeOfWork, Experience
                FROM Doctor", connection);

                    // Создаем объект для записи в файл
                    using (StreamWriter writer = new StreamWriter("Список всех докторов.txt"))
                    {
                        // Выполняем запрос и считываем результаты
                        using (SqlDataReader reader = sqlQuery.ExecuteReader())
                        {
                            // Проверяем, есть ли данные для чтения
                            if (reader.HasRows)
                            {
                                // Читаем данные построчно
                                while (reader.Read())
                                {
                                    // Формируем строку с данными
                                    string row = $"ФИО доктора: {reader["DoctorFullName"]}\n " +
                                                 $"Специальность: {reader["Speciality"]}\n " +
                                                 $"Время работы: {reader["TimeOfWork"]}\n " +
                                                 $"Опыт работы: {reader["Experience"]}\n\n";

                                    // Записываем строку в файл
                                    writer.WriteLine(row);
                                }
                            }
                        }
                    }
                }

                MessageBox.Show("Информация о всех докторах успешно сохранена в файл Список всех докторов.txt");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}
