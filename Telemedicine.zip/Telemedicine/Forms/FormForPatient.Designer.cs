﻿namespace Telemedicine.Forms
{
    partial class FormForPatient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormForPatient));
            this.buttonRecordDoctor = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxSpeciality = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labelInfoDoctor = new System.Windows.Forms.Label();
            this.textBoxDescriptionProblem = new System.Windows.Forms.TextBox();
            this.labelProblem = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.groupBoxDataForDoctor = new System.Windows.Forms.GroupBox();
            this.buttonCreateRecord = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.labelTimeDoctor = new System.Windows.Forms.Label();
            this.labelDoctorID = new System.Windows.Forms.Label();
            this.groupBoxDataForDoctor.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonRecordDoctor
            // 
            this.buttonRecordDoctor.Location = new System.Drawing.Point(533, 52);
            this.buttonRecordDoctor.Name = "buttonRecordDoctor";
            this.buttonRecordDoctor.Size = new System.Drawing.Size(317, 43);
            this.buttonRecordDoctor.TabIndex = 1;
            this.buttonRecordDoctor.Text = "Записаться на сеанс к врачу";
            this.buttonRecordDoctor.UseVisualStyleBackColor = true;
            this.buttonRecordDoctor.Click += new System.EventHandler(this.buttonRecordDoctor_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Выбор врача:";
            // 
            // comboBoxSpeciality
            // 
            this.comboBoxSpeciality.FormattingEnabled = true;
            this.comboBoxSpeciality.Location = new System.Drawing.Point(175, 67);
            this.comboBoxSpeciality.Name = "comboBoxSpeciality";
            this.comboBoxSpeciality.Size = new System.Drawing.Size(197, 28);
            this.comboBoxSpeciality.TabIndex = 3;
            this.comboBoxSpeciality.SelectedIndexChanged += new System.EventHandler(this.comboBoxSpeciality_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Специальность";
            // 
            // labelInfoDoctor
            // 
            this.labelInfoDoctor.AutoSize = true;
            this.labelInfoDoctor.Location = new System.Drawing.Point(171, 107);
            this.labelInfoDoctor.Name = "labelInfoDoctor";
            this.labelInfoDoctor.Size = new System.Drawing.Size(51, 20);
            this.labelInfoDoctor.TabIndex = 5;
            this.labelInfoDoctor.Text = "label3";
            // 
            // textBoxDescriptionProblem
            // 
            this.textBoxDescriptionProblem.Location = new System.Drawing.Point(15, 42);
            this.textBoxDescriptionProblem.Multiline = true;
            this.textBoxDescriptionProblem.Name = "textBoxDescriptionProblem";
            this.textBoxDescriptionProblem.Size = new System.Drawing.Size(413, 100);
            this.textBoxDescriptionProblem.TabIndex = 6;
            // 
            // labelProblem
            // 
            this.labelProblem.AutoSize = true;
            this.labelProblem.Location = new System.Drawing.Point(122, 20);
            this.labelProblem.Name = "labelProblem";
            this.labelProblem.Size = new System.Drawing.Size(164, 20);
            this.labelProblem.TabIndex = 7;
            this.labelProblem.Text = "Описание проблемы";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(122, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(157, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Дата консультации";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(108, 175);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 26);
            this.dateTimePicker.TabIndex = 9;
            // 
            // groupBoxDataForDoctor
            // 
            this.groupBoxDataForDoctor.Controls.Add(this.dateTimePicker);
            this.groupBoxDataForDoctor.Controls.Add(this.textBoxDescriptionProblem);
            this.groupBoxDataForDoctor.Controls.Add(this.label3);
            this.groupBoxDataForDoctor.Controls.Add(this.labelProblem);
            this.groupBoxDataForDoctor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBoxDataForDoctor.Location = new System.Drawing.Point(475, 118);
            this.groupBoxDataForDoctor.Name = "groupBoxDataForDoctor";
            this.groupBoxDataForDoctor.Size = new System.Drawing.Size(434, 222);
            this.groupBoxDataForDoctor.TabIndex = 10;
            this.groupBoxDataForDoctor.TabStop = false;
            this.groupBoxDataForDoctor.Text = "Данные для врача";
            // 
            // buttonCreateRecord
            // 
            this.buttonCreateRecord.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.buttonCreateRecord.Location = new System.Drawing.Point(281, 387);
            this.buttonCreateRecord.Name = "buttonCreateRecord";
            this.buttonCreateRecord.Size = new System.Drawing.Size(270, 94);
            this.buttonCreateRecord.TabIndex = 11;
            this.buttonCreateRecord.Text = "Оформить запись";
            this.buttonCreateRecord.UseVisualStyleBackColor = false;
            this.buttonCreateRecord.Click += new System.EventHandler(this.buttonCreateRecord_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(41, 163);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Время работы";
            // 
            // labelTimeDoctor
            // 
            this.labelTimeDoctor.AutoSize = true;
            this.labelTimeDoctor.Location = new System.Drawing.Point(171, 163);
            this.labelTimeDoctor.Name = "labelTimeDoctor";
            this.labelTimeDoctor.Size = new System.Drawing.Size(51, 20);
            this.labelTimeDoctor.TabIndex = 13;
            this.labelTimeDoctor.Text = "label5";
            // 
            // labelDoctorID
            // 
            this.labelDoctorID.AutoSize = true;
            this.labelDoctorID.Location = new System.Drawing.Point(281, 107);
            this.labelDoctorID.Name = "labelDoctorID";
            this.labelDoctorID.Size = new System.Drawing.Size(51, 20);
            this.labelDoctorID.TabIndex = 14;
            this.labelDoctorID.Text = "label5";
            // 
            // FormForPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 526);
            this.Controls.Add(this.labelDoctorID);
            this.Controls.Add(this.labelTimeDoctor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonCreateRecord);
            this.Controls.Add(this.groupBoxDataForDoctor);
            this.Controls.Add(this.labelInfoDoctor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBoxSpeciality);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonRecordDoctor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(943, 582);
            this.MinimumSize = new System.Drawing.Size(943, 582);
            this.Name = "FormForPatient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Форма для пациента";
            this.Load += new System.EventHandler(this.FormForPatient_Load);
            this.groupBoxDataForDoctor.ResumeLayout(false);
            this.groupBoxDataForDoctor.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonRecordDoctor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxSpeciality;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelInfoDoctor;
        private System.Windows.Forms.TextBox textBoxDescriptionProblem;
        private System.Windows.Forms.Label labelProblem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.GroupBox groupBoxDataForDoctor;
        private System.Windows.Forms.Button buttonCreateRecord;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelTimeDoctor;
        private System.Windows.Forms.Label labelDoctorID;
    }
}