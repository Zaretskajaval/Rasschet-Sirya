﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Telemedicine.Classes;
using Telemedicine.Model;

namespace Telemedicine.Forms
{
    public partial class FormForPatient : Form

    {
        private int patientID;


        public FormForPatient(int patientID)
        {
            InitializeComponent();
            this.patientID = patientID;


        }

        private void FormForPatient_Load(object sender, EventArgs e)
        {
            labelInfoDoctor.Visible = false;
            groupBoxDataForDoctor.Visible = false;
            labelTimeDoctor.Visible = false;    
            labelDoctorID.Visible = false;
            try
            {
                // Получение списка уникальных специальностей врачей из базы данных
                var specialities = Classes.Helper.DB.Doctor.Select(doctor => doctor.Speciality).Distinct().ToList();

                // Заполнение comboBoxSpeciality специальностями
                comboBoxSpeciality.DataSource = specialities;
            }
            catch (Exception ex)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка при загрузке специальностей: " + ex.Message);
            }

        }

        private void comboBoxSpeciality_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string selectedSpeciality = comboBoxSpeciality.SelectedItem.ToString();

                // Получение ФИО врача с выбранной специальностью
                var doctor = Classes.Helper.DB.Doctor.FirstOrDefault(d => d.Speciality == selectedSpeciality);
                if (doctor != null)
                {
                    // Отображение ФИО врача в labelInfoDoctor
                    labelInfoDoctor.Text = "ФИО врача: " + doctor.DoctorFullName;
                    labelInfoDoctor.Visible = true;
                    labelTimeDoctor.Text = "Время работы: " + doctor.TimeOfWork;
                    labelTimeDoctor.Visible = true;
                    labelDoctorID.Text=doctor.DoctorID.ToString();
                }
                else
                {
                    // Если врач с выбранной специальностью не найден
                    labelInfoDoctor.Text = "Врач с выбранной специальностью не найден";
                    labelInfoDoctor.Visible = true;

                   
                }
            }
            catch (Exception ex)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка при отображении информации о враче: " + ex.Message);
            }
        }

        private void buttonRecordDoctor_Click(object sender, EventArgs e)
        {
            groupBoxDataForDoctor.Visible=true; 
        }

        private void buttonCreateRecord_Click(object sender, EventArgs e)
        {
            try
            {

                // Создаем объект подключения к базе данных
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    // Открываем соединение
                    connection.Open();

                    // Создаем SQL-запрос для вставки записи
                    SqlCommand sqlQuery = new SqlCommand("INSERT INTO [ConsultationRequests] (DoctorID, PatientID, DescriptionOfProblem, DateCreateRequest, DateConsultation, TimeOfConsultation, Status) VALUES (@DoctorID, @PatientID, @Description, @DateCreateRequest, @DateConsultation, @TimeOfConsultation, @Status)", connection);

                    // Устанавливаем параметры для SQL-запроса
                    sqlQuery.Parameters.AddWithValue("@DoctorID",Convert.ToInt32(labelDoctorID.Text));
                    sqlQuery.Parameters.AddWithValue("@PatientID", patientID);
                    sqlQuery.Parameters.AddWithValue("@Description", textBoxDescriptionProblem.Text);
                    sqlQuery.Parameters.AddWithValue("@DateCreateRequest", DateTime.Now);
                    sqlQuery.Parameters.AddWithValue("@DateConsultation", dateTimePicker.Value);
                    sqlQuery.Parameters.AddWithValue("@TimeOfConsultation", labelTimeDoctor.Text);
                    sqlQuery.Parameters.AddWithValue("@Status", 1);

                    // Выполняем SQL-запрос
                    sqlQuery.ExecuteNonQuery();

                    MessageBox.Show($"Запись успешно создана! Вы записаны на сеанс к {labelInfoDoctor.Text} дата: {dateTimePicker.Value}");
                }
            }
            catch (Exception ex)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка при создании записи: " + ex.Message);
            }
        }
    }
    
}
