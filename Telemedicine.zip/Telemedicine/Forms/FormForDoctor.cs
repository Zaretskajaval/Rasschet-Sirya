﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Telemedicine.Model;

namespace Telemedicine.Forms
{
    public partial class FormForDoctor : Form
    {
        private int doctorID;

        public FormForDoctor(int doctorID)
        {
            InitializeComponent();
            this.doctorID = doctorID;

        }

        private void FormForDoctor_Load(object sender, EventArgs e)
        {
            try
            {
                // Получение списка пациентов из базы данных
                var patients = Classes.Helper.DB.Patient.Select(pat => pat.PatientFullName).Distinct().ToList();

                // Заполнение comboBoxSpeciality специальностями
                comboBoxPatients.DataSource = patients;
            }
            catch (Exception ex)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка при загрузке пациентов: " + ex.Message);
            }

        }

        private void comboBoxPatients_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string selectedPatient = comboBoxPatients.SelectedItem.ToString();

                var complaints = Classes.Helper.DB.ConsultationRequests.Where(request => request.Patient.PatientFullName == selectedPatient).Select(request => request.DescriptionOfProblem).ToList();

                string[] complaintsArray = complaints.ToArray();

                string allComplaints = string.Join(", ", complaintsArray);

                labelZaloby.Text = allComplaints;
            }
            catch (Exception ex)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка при получении жалоб: " + ex.Message);
            }
        }

        private void buttonSaveProtokol_Click(object sender, EventArgs e)
        {
            try
            {
                // Получение выбранного пациента из comboBox
                string selectedPatient = comboBoxPatients.SelectedItem.ToString();

                // Получение ID выбранного пациента
                int patientID = Classes.Helper.DB.Patient
                    .Where(patient => patient.PatientFullName == selectedPatient)
                    .Select(patient => patient.PatientID)
                    .FirstOrDefault();

                // Получение описания проблемы и даты консультации из ConsultationRequests
                string descriptionOfProblem = Classes.Helper.DB.ConsultationRequests
                    .Where(request => request.Patient.PatientFullName == selectedPatient)
                    .Select(request => request.DescriptionOfProblem)
                    .FirstOrDefault();

                DateTime dateConsultation = Classes.Helper.DB.ConsultationRequests
                    .Where(request => request.Patient.PatientFullName == selectedPatient)
                    .Select(request => request.DateConsultation)
                    .FirstOrDefault();

                // Получение протокола из textBoxProtokol
                string protokol = textBoxProtokol.Text;

                // Создание новой записи в таблице HistoryConsultation
                using (SqlConnection connection = new SqlConnection("Data Source=VOMBAT;Initial Catalog=DBTelemedicine;Integrated Security=True"))
                {
                    connection.Open();

                    SqlCommand sqlQuery = new SqlCommand(@"INSERT INTO [HistoryConsultation] (DoctorID, PatientID, DescriptionOfProblem, DateConsultation, Protokol) 
                                                   VALUES (@DoctorID, @PatientID, @DescriptionOfProblem, @DateConsultation, @Protokol)", connection);

                    sqlQuery.Parameters.AddWithValue("@DoctorID", doctorID);
                    sqlQuery.Parameters.AddWithValue("@PatientID", patientID);
                    sqlQuery.Parameters.AddWithValue("@DescriptionOfProblem", descriptionOfProblem);
                    sqlQuery.Parameters.AddWithValue("@DateConsultation", dateConsultation);
                    sqlQuery.Parameters.AddWithValue("@Protokol", protokol);

                    sqlQuery.ExecuteNonQuery();
                }

                MessageBox.Show("Запись успешно создана!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при создании записи: " + ex.Message);
            }
        }
    }
}
