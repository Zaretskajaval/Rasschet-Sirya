﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Telemedicine.Classes
{
    public class Helper
    {
        //Объявление объекта связи с БД
        public static Model.DBTelemedicineEntities2 DB { get; set; }
    }
}
