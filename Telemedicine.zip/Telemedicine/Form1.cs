﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using Telemedicine.Classes;
using Telemedicine.Model;

namespace Telemedicine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Classes.Helper.DB = new Model.DBTelemedicineEntities2();

        }

        public void buttonAutorization_Click(object sender, EventArgs e)
        {
            string login = textBoxLogin.Text;
            string password=textBoxPassword.Text;
           
            StringBuilder sb = new StringBuilder();
            try
            {
                // Проверка на пустые строки
                if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
                {
                    throw new Exception("Пожалуйста, введите логин и пароль");
                }
                // Получение пользователей из БД
                Model.Administrator admin = Helper.DB.Administrator.Where(adm => adm.Login == login && adm.Password == password).FirstOrDefault();
                Model.Patient patient = Helper.DB.Patient.Where(pat => pat.Login == login && pat.Password == password).FirstOrDefault();
                Model.Doctor doctor = Helper.DB.Doctor.Where(doc => doc.Login == login && doc.Password == password).FirstOrDefault();

                if (admin != null)
                {
                    sb.AppendLine("Здравствуйте, администратор " + admin.AdminName);
                    MessageBox.Show(sb.ToString());
                    Form formForAdmin = new Forms.FormForAdministrator();
                    formForAdmin.Show();
                }
                if (doctor != null)
                {
                    int doctorID = doctor.DoctorID;
                    sb.AppendLine("Здравствуйте, доктор " + doctor.DoctorFullName);

                    MessageBox.Show(sb.ToString());
                    Form formForDoctor = new Forms.FormForDoctor(doctorID);
                    formForDoctor.Show();
                }
                if (patient != null)
                {
                    int patientID= patient.PatientID;
                    sb.AppendLine("Здравствуйте,  " + patient.PatientFullName);
                    MessageBox.Show(sb.ToString());
                    Form fornForPatient = new Forms.FormForPatient(patientID);
                    fornForPatient.Show();
                }
            
            }
            catch (Exception ex)
            {
                // Обработка исключения
                MessageBox.Show("Ошибка: " + ex.Message);
            }
        }
    }
}
