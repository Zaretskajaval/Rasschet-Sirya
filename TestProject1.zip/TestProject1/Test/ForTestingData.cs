﻿using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Telemedicine;
using Telemedicine.Classes;
using Telemedicine.Model;
using TestProjectForTelemedicine.Test;

namespace TestProject1.Test
{
    public class ForTestingData
    {

        public void LoginAndPasswordIsEmpty(string loginData, string passwsordData)
        {
            string login = loginData;
            string password = passwsordData;



            try
            {
                // Проверка на пустые строки
                if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
                {
                    throw new Exception("Пожалуйста, введите логин и пароль");
                }

            }
            catch (Exception ex)
            {

            }

        }

        public void SendDataAboutDoctorFromAnotherForm()
        {
            int doctorID = 1;
            AcceptDataAboutDoctor(doctorID);


        }
        public void AcceptDataAboutDoctor(int doctorID)
        {
            int docID = doctorID;
            if (docID == doctorID)
            {
                Message.Equals(true, doctorID);
            }
        }

     
        public void SendDataAboutPatientFromAnotherForm()
        {
            int PatientID = 1;
            AcceptDataAboutPatient(PatientID);

        }
        public void AcceptDataAboutPatient(int PatientID)
        {
            int patID = PatientID;
            if (patID == PatientID)
            {
                Message.Equals(true, PatientID);
            }
        }

        public void LogAndPassIsEmpty(string loginData, string passwsordData)
        {
            UserCredentials userCredentials = new UserCredentials();

            try
            {
                if (!userCredentials.IsValidCredentials(loginData, passwsordData))
                {
                    throw new Exception("Нет такого логина или пароля");
                }
                else
                {
                    Console.WriteLine("Вход выполнен успешно");
                    // Дальнейшие действия после успешного входа
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

    }
}
