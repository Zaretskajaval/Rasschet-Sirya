﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProjectForTelemedicine.Test
{
    public class UserCredentials
    {
        private Dictionary<string, string> credentials = new Dictionary<string, string>();

        public UserCredentials()
        {
           
            credentials.Add("user1", "password1");
            credentials.Add("user2", "password2");
           
        }

        public bool IsValidCredentials(string login, string password)
        {
            return credentials.ContainsKey(login) && credentials[login] == password;
        }
    }
}
